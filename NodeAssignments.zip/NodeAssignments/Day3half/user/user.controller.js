var UserService = require('./user.service')

exports.login = function(req,res){
    console.log("i will call the function in service")
    UserService.readUser().then(function(result){
        console.log("Request resolved" , result)
        res.send({
            message:result
        })
    }, function(error){
        console.log("Rejection called" , error)
        res.status(500).send({
            error:"Internal Server Error"
        })
    })
    
}


exports.register = function(req,res){

}

exports.allUsers = function(req,res){
    
}

exports.deleteAccount = function(req,res){
    
}
