var fs = require('fs')

exports.readUser =  function(data){
    // task here 
    // Async code 
    return new Promise(function(resolve,reject){
        // task wwill start and based on outcome of task 
        // we will either call reject or call resolve
        fs.readFile(__dirname + '/user.json', function(error,data){
            if(error){
                reject(error)
            }
            else{
                
                resolve(JSON.parse(data.toString()))
            }
        })
    })
}

// functionality // flow 
// how that functionality will be done

// what functionality ?
