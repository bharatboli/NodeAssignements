const express = require('express')
const UserController = require('./user.controller')

var router = express.Router()

router.get('/allusers', UserController.allUsers)
router.post('/register', UserController.register)
router.post('/login', UserController.login)
router.delete('/deleteaccount', UserController.deleteAccount)



module.exports = router

// localhost:5000/api/user/login