const express = require('express')

var router = express.Router()

router.use('/user', require('./user'))
router.use('/cake', require('./cake'))



module.exports = router


// localhost:5000/api/user
// localhost:5000/api/cake


// If we mention folder name they default look for 
// index.js