const express = require('express')

var router = express.Router()





module.exports = router


// localhost:5000/api/user