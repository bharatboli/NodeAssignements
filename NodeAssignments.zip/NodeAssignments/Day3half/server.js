const express = require('express')
const fs = require('fs')
const Port = 5000
const server = express()


server.use('/api', require('./routes'))






server.listen(Port, function(){
    console.log("Server is running on", Port)
})

// localhost:5000/api