const express = require('express')

var router = express.Router()

router.use('/user', require('./user'))
router.use('/cake', require('./cake'))



module.exports = router