var EventEmitter = require('events')
var Traineemodel = require('./trainee.model')
var AuthController = require('../Auth.controller')

exports.findTrainee = (data)=>{
    var emitter = new EventEmitter()
   Traineemodel.findOne(data).then(function(result){
       console.log(".... ressult of login", result)
       if(result){
        var datatosign = {
            name:result.name,
            email:result.email
        }
        AuthController.createToken(datatosign)
        .then(function(result){
          emitter.emit('SUCCESS' , result)   
        }, function(error){
            emitter.emit('ERROR')
        })
       }
       else{
           emitter.emit('NOT_FOUND')
       }
   }, function(error){
       emitter.emit('ERROR')
   })

   return emitter
}

exports.createTrainee = (data)=>{
    var emitter = new EventEmitter()
    var traineedata =  new Traineemodel(data)
   traineedata.save().then(function(result){
       console.log(".... ressult of register", result)
       if(result){
        emitter.emit('SUCCESS')
       }
       
   }, function(error){
       if(error.code==11000){
           emitter.emit('DUPLICATE')
       }
       else{
        emitter.emit('ERROR')
       }
   })

   return emitter
}