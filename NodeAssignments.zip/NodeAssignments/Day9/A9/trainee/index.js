const express = require('express')
const TraineeController = require('./trainee.controller')

// import {recoverPasswordNew} from "./user.controller"

var router = express.Router()

router.post('/login', TraineeController.login)
router.post('/register', TraineeController.register)



module.exports = router

// localhost:5000/api/user/login