var Mongoose = require('mongoose')

var TraineeSchema =  Mongoose.Schema({
    email:{type:String, unique:true, require:true},
    password:{type:String, required:true},
    name:{type:String, required:true},
    createdat:{type:Date , default:new Date()},
    role:{type:String, default:"user"}
})

var traineemodel= Mongoose.model('trainees' , TraineeSchema)

module.exports = traineemodel