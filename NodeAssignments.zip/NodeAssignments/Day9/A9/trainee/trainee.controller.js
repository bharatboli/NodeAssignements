var TraineeService =  require('./trainee.service')

exports.login =  (req,res)=>{
    var query = {
        email:req.body.email,
        password:req.body.password
    }
    TraineeService.findTrainee(query)
    .on('SUCCESS', function(token){  
        res.set('securitytoken',token)
        res.send({
            message:"LOGIN SUCCESS"
        })
    })
    .on('ERROR', function(){
        res.status(500).send({
            error:"INTERNAL SERVER ERROR"
        })
    })
    .on('NOT_FOUND', function(){
        res.send({
            message:"INvalid Credentials"
        })
    })

}


exports.register =  (req,res)=>{
   
    TraineeService.createTrainee(req.body)
    .on('SUCCESS', function(){  
        
        res.send({
            message:"Register SUCCESS"
        })
    })
    .on('ERROR', function(){
        res.status(500).send({
            error:"INTERNAL SERVER ERROR"
        })
    })
    .on('DUPLICATE', function(){
        res.send({
            message:"user already exists with this email"
        })
    })
  

}