const express = require('express')
const fs = require('fs')
const Port = 7000
const server = express()
const bodyparser = require('body-parser')
const Mongoose = require('mongoose')
const dburl = "mongodb://localhost:27017/tcsnodedb"

Mongoose.connect(dburl).then(function(client){
    if(client){
        console.log("Connected to database")
    }  
}, function(error){
    console.log("Error in connecting to database" , error)
})

server.use(bodyparser.json())
server.set('view engine' ,'ejs')

server.use('/api', require('./routes'))




server.get('/', function(req,res){
    var user = {
        name:"Diego Simonelli",
        email:"abc@tcs.com"
    }
    res.render('index' ,{userdata:user})
})

// While creating the view what ever data we have to present we will put it 
// from the server self and then finally render the view to the user 


module.exports = server.listen(Port, function(){
    console.log("Server is running on", Port)
})

// localhost:5000/api