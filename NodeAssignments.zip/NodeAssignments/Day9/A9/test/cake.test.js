const { expect } = require('chai')
var chai = require('chai')
var chaiHttp = require('chai-http')
var server = require('../server')
var should = chai.should()


chai.use(chaiHttp)


describe('Cake Api Testing', ()=>{


    it('GET CAKES:API should get all the cakes with status 200' , (done)=>{
           chai.request(server)
           .get('/api/cake/allcakes').end((error,response)=>{
               console.log("response" , response.body)
                response.should.have.status(200)
                response.body.should.be.a('object')
                response.body.should.have.property('data')
                done()
           })
    })

    it('GET CAKES:API should get all the cakes with status code 200 ' , (done)=>{
        chai.request(server)
        .post('/api/cake/addcake').send({name:"Dummy Cake" , price:123,description:"some description" ,flavour:"Chocolate"}).end((error,response)=>{
            console.log("response" , response.body , error)
             response.should.have.status(200)
             response.body.should.be.a('object')
             /* response.body.should.have.property('message') */
             response.body.should.have.property('cake')
             done()
        })
    })
    it('GET CAKES: it will give status code 400 without sending anything in body' , (done)=>{
        chai.request(server)
        .post('/api/cake/addcake').send({ }).then((res)=>{
            expect(res).to.have.status(400)
            done()
        })
        .catch((err)=>{throw(err)})
    })
})

// We just created an api Our requirement is to test wether it is working fine or not
// we will write a test for that