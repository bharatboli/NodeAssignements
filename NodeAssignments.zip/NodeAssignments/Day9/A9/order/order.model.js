var Mongoose = require('mongoose')

var orderschema =   Mongoose.Schema({
  name:{type:String , required:true},
  status:{type:String , required:true , default:'inprogress'},
  orderdate:{type:Date, default : new Date() ,required:true},
  address:{type:String, required:true},
  email:{type:String , required:true},
  price:{type:Number , required:true},
  orderid:{type:Number , unique:true , required:true},
  shopping:[
      {
        cakeid:{type:Number, required:true},
        price:{type:Number, required: true}
      }
  ],
  

})

var ordermodel = Mongoose.model('orders',orderschema)
module.exports = ordermodel