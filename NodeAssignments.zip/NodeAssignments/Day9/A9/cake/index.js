const express = require('express')
const CakeController = require('./cake.controller.js')
const AuthController =  require('../Auth.controller')

var router = express.Router()

router.post('/addcake', CakeController.addCake)
router.get('/allcakes' ,CakeController.allCakes)


router.get('/:cakeid', AuthController.isAdmin , CakeController.getOne)



module.exports = router


// localhost:5000/api/user

// in point u nned to write a function/api which will add new admin users but protected by isAdmin middleware