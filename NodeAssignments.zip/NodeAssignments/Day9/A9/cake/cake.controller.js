var CakeService = require('./cake.service')

exports.addCake =  function(req,res){
    CakeService.createCake(req.body).then(function(result){
        res.send({
            mesage:"Cake added!",
            cake:result
        })
    } , function(){
        res.status(500).send({
            error:"Internal Server Error"
        })
    })
}


exports.allCakes = function(req,res){
    CakeService.allCakes().then(function(result){
        res.send({
           data:result
        })
    } , function(){
        res.status(500).send({
            error:"Internal Server Error"
        })
    })
}

exports.allCakesblocking = function(req,res){
    CakeService.allCakes1()
}

exports.getOne = function(req,res){
    CakeService.getCakeDetails(req.params.cakeid).then(function(result){
        // res.send({
        // message:"Cake Details",
        // cake: result
        // })
        result.ingredients = ["Milk" , "Cream" , "Eggs" ,"Almonds" ,"Sugar"]
        res.render('cakedetails',{cakedata:result})
    }, function(){
        res.status(500).send({
            error:"Internal server error"
        })
    })
    
}

// How SSR is faster ?