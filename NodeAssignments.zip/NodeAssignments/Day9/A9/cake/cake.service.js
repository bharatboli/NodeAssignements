var CakeModel = require('./cake.model')


exports.createCake = function(data){
 return new Promise(function(resolve,reject){
    data.cakeid = Date.now()
    var validcakedata = new CakeModel(data)
    console.log("Cake schema vaidated" , validcakedata)
    validcakedata.save().then(function(result){
        console.log("Cake added to database" , result)
        resolve(result)
    }, function(error){
        console.log("Error in storing in database" , error)
        reject()
    })
 })
}

exports.allCakes1 = async function(){
    
       var allcakes = await CakeModel.find({})
       console.log(">>>>>>>>>>>>>>>>>>>>>>" ,allcakes)
    
}

exports.allCakes =  function(){
    return new Promise(function(resolve, reject){
        var findQuery = {}
        var projection = {
            name:1,
            price:1,
            cakeid:1,
            _id:0
        }
     var allcakes =  CakeModel.find(findQuery , projection).then(function(result){
            console.log("cakes found" , result)
            resolve(result)
        }, function(error){
            reject(error)
        })

        console.log("....... non blocking one" , allcakes)
    })
}

exports.getCakeDetails = function(cakeid){
    return new Promise(function(resolve,reject){
        console.log(">>>>>>>>>> cakeid for which we have to find the details" , cakeid)
   var findQuery = {
      cakeid:cakeid
   }  
   CakeModel.findOne(findQuery).then(function(result){
       console.log("cake details found are" , result)
       resolve(result)
   }, function(error){
       console.log("error in finding cake details" , error)
       reject(error)
   })
    })
  
}

// exports.getCakeDetails =  function(cakeid){
//     return new Promise(function(resolve,reject){
//         console.log(">>>>>>>>>> cakeid for which we have to find the details" , cakeid)
//    var findQuery = {
//       cakeid:cakeid
//    }  
//  CakeModel.findOne(findQuery).then((result)=>{
// resolve(result)
//  },(error)=>{

//  })

   
//     })
  
// }


// Create an api to retrieve cakeid and based on that api u need
// to return details of that cake
// CakeModel.find({}).then()

// by default is non blocking

// from await code we are turning it into blocking

// whenever we do this thing we nned to mention that function
// with async key









