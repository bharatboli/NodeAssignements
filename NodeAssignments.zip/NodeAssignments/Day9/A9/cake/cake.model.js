var Mongoose = require('mongoose')

var cakeschema =   Mongoose.Schema({
  name:{type:String , required:true},
  description:{type:String , required:true},
  price:{type:Number , required:true},
  cakeid:{type:Number , unique:true , required:true},
  flavour:{type:String , required:true},
  weight:{type:Number, default:1},
  eggless:{type:Boolean , default:true}

})

var cakemodel = Mongoose.model('cakes',cakeschema)
module.exports = cakemodel


// dateofinsertion :{type:Date , default: new Date()}

