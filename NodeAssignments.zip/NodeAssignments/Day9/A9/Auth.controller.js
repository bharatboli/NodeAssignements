var jwt = require('jsonwebtoken')
var Traineemodel = require('./trainee/trainee.model')

exports.createToken =  function(data){
    return new Promise(function(resolve,reject){
        console.log("this data we have to sign" , data)
        jwt.sign(data,'iloveyou',function(error, token){
            if(error){
                reject()
            }
            else{
                console.log("token" ,token)
                resolve(token)
            }
        })
    })
   
// by using this data we will create a unique token
}

// this function is just taking token from the request headers and verifying it wether 
// request token is valid or not
exports.isAuthenticated = function(req,res,next){
    var tellusthesecuretoken = req.get('token') // checking for header named token
    console.log("is request having token" , tellusthesecuretoken)
    if(tellusthesecuretoken){
       jwt.verify(tellusthesecuretoken,'iloveyou', function(error,data){
           console.log("verification of token result is" , error, data)
           if(error){
               res.render('notauthorised')
           }
           else{
                next()
           }
       })
    }
    else{
        res.render('notauthorised')
    }
}

exports.isAdmin = function(req,res,next){
    var tellusthesecuretoken = req.get('token') // checking for header named token
    console.log("is request having token" , tellusthesecuretoken)
    if(tellusthesecuretoken){
       jwt.verify(tellusthesecuretoken,'iloveyou', function(error,data){
           console.log("verification of token result is" , error, data)
           if(error){
               res.render('notauthorised')
           }
           else{
               // token is valid now we will check for role authorisation
              var query = {
                  email:data.email
              }
              Traineemodel.findOne(query).then(function(result){
                  if(result.role=="admin"){
                      next()
                  }
                  else{
                      res.render('notadmin')
                  }
              })
           }
       })
    }
    else{
        res.render('notauthorised')
    }
}