const express = require('express')
const UserController = require('./user.controller')

// import {recoverPasswordNew} from "./user.controller"

var router = express.Router()

router.get('/allusers' ,UserController.allUsers)
router.post('/register', UserController.register)
router.post('/login', UserController.login)
router.get('/employee/:id', UserController.login) 
router.get('/project/:id', UserController.getProject)  
router.get('/employeedetails', UserController.getProjectDetails)    


router.post('/recoverpassword', UserController.recoverPassword)
router.delete('/deleteaccount', UserController.deleteAccount)



module.exports = router

// localhost:5000/api/user/login