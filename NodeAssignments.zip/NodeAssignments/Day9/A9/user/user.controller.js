var UserService = require('./user.service')

// export let recoverPasswordNew = async (req,res)=>{}
exports.recoverPassword = async function(req,res){
   var result  =  await  UserService.sendMail(req.body.email).catch(
       function(){
           res.status(500).send({
               error:"Internal Server Error"
           })
       }
   )
   console.log("Now result of sending email is" , result)
   if(result==null){
       res.send({
           message:"No Such Email exits"
       })
   }
   else if(result.messageId){
       res.send({
           message:"Pssword Sent Successfully",
       })
   }
}

exports.login = function(req,res){
    console.log("req body" , req.body)
    console.log("i will call the function in service ")
    // UserService.readUser().then(function(result){
    //     console.log("Request resolved" , result)
    //     res.send({
    //         message:result
    //     })
    // }, function(error){
    //     console.log("Rejection called" , error)
    //     res.status(500).send({
    //         error:"Internal Server Error"
    //     })
    // })
    var query = {
        email:req.body.email,
        password:req.body.password
    }
    UserService.findUser(query)
    .on('ERROR', function(){
        res.status(500).send({
            error:"Internal Server Error"
        })
    })
    .on('SUCCESS', function(data){
        res.send({
            message:"Login_Success",
            employeedetails:data
        })
    })
    .on('INVALID_PASSWORD', function(){
        res.send({
            message:"Invalid Credentials"
        })
    })
    .on('NO_SUCH_EMAIL', function(){
        res.send({
            message:"Invalid Email"
        })
    })  
}


exports.getProject = function(req,res){
    console.log("req body" , req.body)
    console.log("i will call the function in service ")
    // UserService.readUser().then(function(result){
    //     console.log("Request resolved" , result)
    //     res.send({
    //         message:result
    //     })
    // }, function(error){
    //     console.log("Rejection called" , error)
    //     res.status(500).send({
    //         error:"Internal Server Error"
    //     })
    // })
    var query = {
        email:req.body.email,
        password:req.body.password
    }
    UserService.findProject(req.params.id)
    .on('ERROR', function(){
        res.status(500).send({
            error:"Internal Server Error"
        })
    })
    .on('SUCCESS', function(data){
        res.send({
            message:"Login_Success",
            employeedetails:data
        })
    })
    .on('INVALID_PASSWORD', function(){
        res.send({
            message:"Invalid Credentials"
        })
    })
    .on('NO_SUCH_EMAIL', function(){
        res.send({
            message:"Invalid Email"
        })
    })  
}


exports.register = function(req,res){

}

exports.allUsers = function(req,res){
    
}

exports.deleteAccount = function(req,res){
    
}


exports.getProjectDetails = function(req,res){

     UserService.getDetails("ashu.lekhi0540@gmail.com")
     .on('SUCCESS', function(data){
         res.send({
             employeedetails:data
         })
     })
}
