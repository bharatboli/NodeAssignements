var fs = require('fs')
var EventEmitter = require('events')
var nodemailer = require('nodemailer')
var fetch = require('node-fetch')




exports.readUser =  function(data){
    // task here 
    // Async code 
    return new Promise(function(resolve,reject){
        // task wwill start and based on outcome of task 
        // we will either call reject or call resolve
        fs.readFile(__dirname + '/user.json', function(error,data){
            if(error){
                reject(error)
            }
            else{
                
                resolve(JSON.parse(data.toString()))
            }
        })
    })
}

exports.sendMail = async function(email){
    var filedata =  fs.readFileSync(__dirname+'/user.json')
    var users = JSON.parse(filedata.toString())
    console.log("file data" , users)
    if(users[email]){
        let transporter = nodemailer.createTransport({
            service: "gmail",
            port: 587,
            secure: false, // true for 465, false for other ports
            auth: {
              user: "", // generated ethereal user
              pass: "", // generated ethereal password
            },
          });
        
          // send mail with defined transport object
          let info = await transporter.sendMail({
            from: '"NO Reply ? 👻" <lekhi.sahab@gmail.com>', // sender address
            to: email , // list of receivers
            subject: "Password Recovery ", // Subject line
            text: "Your Password is ", // plain text body
            html: `<b>${users[email].password}</b>`, // html body
          });
        
          console.log("Message sent: %s", info.messageId);
          // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>
        
          // Preview only available when sending through an Ethereal account
          console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));

          return info
    }
    else{
        return null
    }

}


exports.findUser =  function(query){
    console.log("We have to check credentials for this data", query)
    var emitter = new EventEmitter()
    fs.readFile(__dirname+'/user.json', function(error,data){
        if(error){
            emitter.emit('ERROR', error)
        }
        else{
            var users = JSON.parse(data.toString())
            console.log("data from user.json file ,  data" , users  , users[query])
            if(users[query]){
                // if(users[query.email].password==query.password){
                //     emitter.emit("SUCCESS")
                // }
                // else{
                //     emitter.emit("INVALID_PASSWORD")
                // }
                emitter.emit('SUCCESS', users[query])
            }
            else{
                emitter.emit("NO_SUCH_EMAIL")
            }
        }
    })




    return emitter
}


exports.findProject =  function(query){
    console.log("We have to check credentials for this data", query)
    var emitter = new EventEmitter()
    fs.readFile('projects.json', function(error,data){
        if(error){
            emitter.emit('ERROR', error)
        }
        else{
            var users = JSON.parse(data.toString())
            console.log(">>>>>>>>>>>>>>>>data from projects.json file ,  data" , users  , users[query])
            if(users[query]){
                // if(users[query.email].password==query.password){
                //     emitter.emit("SUCCESS")
                // }
                // else{
                //     emitter.emit("INVALID_PASSWORD")
                // }
                emitter.emit('SUCCESS', users[query])
            }
            else{
                emitter.emit("NO_SUCH_EMAIL")
            }
        }
    })




    return emitter
}
// emit the custom user messages

// functionality // flow 
// how that functionality will be done

// what functionality ?


exports.getDetails =  function(data){
    let emitter = new EventEmitter()
// http call for getting employee data
// for getting employee data
var url = "http://localhost:5000/api/user/employee/"+data

fetch(url)
    .then(res => res.json())
    .then(response =>{ 
        console.log(", response of employee details",response)
     var projectapiurl = "http://localhost:5000/api/user/project/"+response.employeedetails.projectid
     fetch(projectapiurl).then(res => res.json()).then(projectdetails=>{
         console.log("proejct details are" , projectdetails)
         var responseObj = {
             employeedetails:response,
             project:projectdetails
         }

         console.log("final oject need to send at backend is", responseObj)
         emitter.emit('SUCCESS', responseObj)
        })


});

// }).then(function(response){
//     console.log("employee data",  response)
//     // fetch(url).then(function(responseofproject){
//     //   var responseObj = {
//     //       "employeedetails": response.something,
//     //       "projectdetails" : responseofproject.something
//     //   }


//     // }, function(){})
// }, function(error){

// })

return emitter
}


exports.getALLUSERS  =  function(){
    var url = "http://5c055de56b84ee00137d25a0.mockapi.io/api/v1/employees"
    fetch(url)
    .then(res => res.json())
    .then(response =>{
        console.log("response " , response)
        var users = response 
        var modifieddata = users.map((each)=>{
            delete each["avatar"]
            return each
        })

        console.log("we have removed avatar from each object in array using loop")
        console.log(modifieddata)
    })
   

   
}



